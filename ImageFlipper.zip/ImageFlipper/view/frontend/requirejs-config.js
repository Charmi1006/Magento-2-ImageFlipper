var config = {
    paths: {
         "magebeesFlipper": "Magebees_ImageFlipper/js/magebees_flipper"
    },
    shim: {
        'magebeesFlipper': {
            deps: ['jquery']
        }
        
        
    }
};



